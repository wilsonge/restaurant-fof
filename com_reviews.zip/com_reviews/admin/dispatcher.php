<?php
/**
 * @copyright (C) 2013 JoomJunk. All rights reserved.
 * @package    Restaurant Reviews
 * @license    http://www.gnu.org/licenses/gpl-3.0.html
 **/

defined('_JEXEC') or die();

class ReviewsDispatcher extends FOFDispatcher
{
	public $defaultView = 'restaurants';
}
