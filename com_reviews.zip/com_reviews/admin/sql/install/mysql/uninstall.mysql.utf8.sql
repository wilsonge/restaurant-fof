DROP TABLE IF EXISTS `#__reviews_restaurants`;
DROP TABLE IF EXISTS `#__reviews_comments`;